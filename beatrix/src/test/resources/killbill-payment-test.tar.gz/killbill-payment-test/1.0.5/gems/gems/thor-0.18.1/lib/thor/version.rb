class Thor
  VERSION = "0.18.1"
end
