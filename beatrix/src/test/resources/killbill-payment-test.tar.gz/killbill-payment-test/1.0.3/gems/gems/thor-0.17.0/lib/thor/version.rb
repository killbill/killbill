class Thor
  VERSION = "0.17.0"
end
