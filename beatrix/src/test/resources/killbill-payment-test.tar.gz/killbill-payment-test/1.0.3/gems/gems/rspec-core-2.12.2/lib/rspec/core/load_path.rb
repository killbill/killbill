require 'rspec/core/ruby_project'

RSpec::Core::RubyProject.add_to_load_path('lib', 'spec')
