module RSpec
  module Core
    module Version
      STRING = '2.12.2'
    end
  end
end
