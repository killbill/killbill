require 'sinatra/base'
require 'sinatra/main'

enable :inline_templates
