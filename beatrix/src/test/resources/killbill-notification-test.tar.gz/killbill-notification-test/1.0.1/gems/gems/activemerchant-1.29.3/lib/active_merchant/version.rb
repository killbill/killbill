module ActiveMerchant
  VERSION = "1.29.3"
end
