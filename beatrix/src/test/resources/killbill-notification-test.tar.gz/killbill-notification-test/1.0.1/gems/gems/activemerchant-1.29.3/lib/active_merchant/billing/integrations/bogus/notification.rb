module ActiveMerchant #:nodoc:
  module Billing #:nodoc:
    module Integrations #:nodoc:
      module Bogus
        class Notification < ActiveMerchant::Billing::Integrations::Notification

        end
      end
    end
  end
end
