module ActiveMerchant #:nodoc:
  module Billing #:nodoc:
    module Integrations #:nodoc:
      module Nochex
        class Return < ActiveMerchant::Billing::Integrations::Return
	      end
      end
    end
  end
end
