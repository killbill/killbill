module ActiveUtils
  VERSION = "1.0.5"
end
