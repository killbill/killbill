module ActiveMerchant #:nodoc:
  module Billing #:nodoc:
    module Integrations #:nodoc:
      module Dotpay
        class Return < ActiveMerchant::Billing::Integrations::Return
        end
      end
    end
  end
end

