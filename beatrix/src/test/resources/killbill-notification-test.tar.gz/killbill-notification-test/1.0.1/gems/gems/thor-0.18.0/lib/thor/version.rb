class Thor
  VERSION = "0.18.0"
end
