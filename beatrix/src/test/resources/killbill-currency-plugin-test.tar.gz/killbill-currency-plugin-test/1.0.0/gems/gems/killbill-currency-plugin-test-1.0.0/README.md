killbill-currency-plugin
==============================

A currency plugin used for integration tests.
