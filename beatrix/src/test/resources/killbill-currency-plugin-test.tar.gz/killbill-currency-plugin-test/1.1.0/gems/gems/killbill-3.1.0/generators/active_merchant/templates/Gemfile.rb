source 'http://rubygems.org'

gemspec
